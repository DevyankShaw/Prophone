package com.example.devyankshaw.checking.HomeKeyListener;

public interface OnHomePressedListener {

    void onHomePressed();
    void onHomeLongPressed();
}
