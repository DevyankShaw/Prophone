package com.example.devyankshaw.checking.WallpaperChange;

public class WallpaperItem {
    private int imageView1, imageView2;

    public WallpaperItem(int imageView1, int imageView2) {
        this.imageView1 = imageView1;
        this.imageView2 = imageView2;
    }

    public int getImageView1() {
        return imageView1;
    }

    public int getImageView2() {
        return imageView2;
    }
}
